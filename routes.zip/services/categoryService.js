//reference of dbconnection.js
var category = require('../dao/categoryDAO');
var banners = require('../dao/bannersDAO');
var discounts = require('../dao/discountsDAO');
var orderitems = require('../dao/orderItemsDAO');
const common = require('../common');
var cartService = require('../services/cartService');
var bannersService = require('../services/bannersService');
var async = require("async");

var categoryService = {
    //All categories list
    categoriesList: function (req, callback) {
        async.series([
            function (done) {
                category.getAllCategories(function (err, category_data) {
                    if (err) {
                        done(null, { "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
                    } else {
                        if (category_data.length > 0) {
                            var category_list = formCategoriesStructure(category_data)
                            done(null, { "status": 200, "err_field": "", "message": "Success", result: category_list });
                        } else {
                            done(null, { "status": 400, "err_field": "", "message": "No records found" });
                        }
                    }
                })
            },
            function (done) {
                bannersService.getAllbanners(function (bannersData) {
                    done(null,bannersData);
                });
            }, function (done) {
                discounts.getAlldiscounts(function (err, discounts_data) {
                    if (err) {
                        done(null, { "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
                    } else {
                        if (discounts_data.length > 0) {
                            done(null, { "status": 200, "err_field": "", "message": "Success", result: discounts_data });
                        } else {
                            done(null, { "status": 400, "err_field": "", "message": "No records found" });
                        }
                    }
                })
            }, function (done) {
                orderitems.getPopularProducts(10, function (err, popular_data) {
                    if (err) {
                        done(null, { "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
                    } else {
                        if (popular_data.length > 0) {
                            done(null, { "status": 200, "err_field": "", "message": "Success", result: popular_data });
                        } else {
                            done(null, { "status": 400, "err_field": "", "message": "No records found" });
                        }
                    }
                })
            }, function (done) {
                var user_data = req.body;
                common.check_token(req, function (decoded) {
                    var user_id = '';
                    if (decoded.status == 200) {
                        user_id = decoded.decoded.u_id;
                    } else {
                        user_id = user_data.session_id;
                    }

                    if (common.gNUE(user_id) == '') {
                        done(null, { "status": 400, "message": "Required field is missing" });
                    } else {
                        cartService.getMyCartItems(user_id, function (data) {
                            done(null, data);
                        });
                    }
                });
            }
        ], function (err, results) {

            var category = []; var banners = []; var discounts = []; var popular = []; var summary = {};
            if (results[0].status == 200) {
                category = results[0].result;
            }
            if (results[1].status == 200) {
                banners = results[1].result;
            }
            if (results[2].status == 200) {
                discounts = results[2].result;
            }
            if (results[3].status == 200) {
                popular = results[3].result;
            }
            if (results[4].status == 200) {
                summaryData = results[4].data;
                var actual_price = 0; var offer_price = 0;
                for (var i in summaryData) {
                    for (var j in summaryData[i].sku) {
                        var skudata = summaryData[i].sku[j];
                        actual_price += skudata.actual_price;
                        offer_price += skudata.offer_price;
                    }
                }
                var delivery_charge = 50;
                var grand_total = delivery_charge + offer_price;
                summary = {
                    "cart_count": summaryData.length,
                    "realization": "0",
                    "mrp": actual_price,
                    "selling_price": offer_price,
                    "delivery_charge": delivery_charge,
                    "grand_total": grand_total
                };
            }
            var final_result = {
                "status": "success",
                "message": "Fetch Successful.",
                "id_customer": "",
                "result": {
                    "customer": '',
                    "category": category,
                    "banner": banners,
                    "offers": discounts,
                    "popular": popular,
                },
                "summary": summary
            };
            callback(final_result);
        });

    },
    getAllCategoriesDetail: function (done) {
        category.getAllCategories(function (err, category_data) {
            if (err) {
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            } else {
                if (category_data.length > 0) {
                    var category_list = formCategoriesStructure(category_data);
                    done({ "status": 200, "err_field": "", "message": "Success", result:category_list});
                } else {
                    done({ "status": 400, "err_field": "", "message": "No records found" });
                }
            }
        });
    },
    getAllCategoriesDetail_dashbord:function(done)
    {
           category.getAllCategories(function (err, category_data) {
            if (err) {
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            } else {
                if (category_data.length > 0) {
                    var category_list = formCategoriesStructure(category_data);
                    done(category_list);
                } else {
                    done({ "status": 400, "err_field": "", "message": "No records found" });
                }
            }
        });
        
    },
    getAllCategoriesDetailWithLimit: function (start,limit,done) {
        category.getAllCategoriesWithlimit(start,limit,function (err, category_data) {
            if (err) {
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            } else {
                if (category_data.length > 0) {
                    var category_list = formCategoriesStructure(category_data);
                    done({ "status": 200, "err_field": "", "message": "Success", result: category_list });
                } else {
                    done({ "status": 400, "err_field": "", "message": "No records found" });
                }
            }
        });
    },
    getCategoryById:function(id,done){
        category.getCategoryById(id, function (err, category_data) {
            if (err) {
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            } else {
               if(category_data.length>0){
                var category_data = formCategoriesStructure(category_data);
                done({ "status": 200, "err_field": "", "message": "Success","categoryinfo":category_data });
               }else{
                done({ "status": 400, "err_field": "", "message": "No records found" });
               }
            }
        });
    }
};

function formCategoriesStructure(category_data){
    var category_list = [];
    for (let i in category_data) {
        if (category_data[i].parent_cat_id == null || category_data[i].parent_cat_id == '') {
            category_list.push({
                "id": category_data[i].id,
                "name": category_data[i].name,
                "pic": category_data[i].pic,
                "description": category_data[i].description
            });
        }
    }
    for (let i in category_list) {
        for (let j in category_data) {
            if (category_data[j].parent_cat_id == category_list[i].id) {
                if (category_list[i].subcategory == undefined) {
                    category_list[i].subcategory = [];
                }
                category_list[i].subcategory.push({
                    "id": category_data[j].id,
                    "name": category_data[j].name,
                    "pic": category_data[j].pic,
                    "description": category_data[j].description,
                    "parent_cat_id": category_data[j].parent_cat_id,
                    "express": 1
                });
            }
        }
    }
    return category_list;
}

module.exports = categoryService;