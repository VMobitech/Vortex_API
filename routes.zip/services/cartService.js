//reference of dbconnection.js
var cart = require('../dao/cartDAO');
const common = require('../common');
var productsSkuDAO = require('../dao/skuDAO');

var cartService = {
    getMyCartItems:function(user_id,done){
        cart.getCartItemsByUserId(user_id,function (err, cart_data) {
            if(err){
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
            }else{
               if(cart_data.length > 0){
                    var product_ids_arr = [];var sku_arr = [];
                    for(var i in cart_data){
                        cart_data[i].sku = [];
                        product_ids_arr.push(cart_data[i].product_id);
                        sku_arr.push(cart_data[i].product_sku_id);
                    }
                    var product_ids = product_ids_arr.join(',');
                    var sku_ids = sku_arr.join(',');
                    var reqParamsObj = {product_id:product_ids,sku_ids:sku_ids}
                    productsSkuDAO.getProductSkuByProductIdAndSkuId(reqParamsObj,function (err, sku_data){
                        if(!err){
                            if(sku_data.length > 0){
                                for(var j in sku_data){
                                    for(var i in cart_data){
                                        if(cart_data[i].product_id == sku_data[j].product_id){
                                            sku_data[j].mycart = cart_data[i].quantity;
                                            cart_data[i].sku.push(sku_data[j]);
                                            delete cart_data[i].quantity;
                                        }
                                    }
                                }
                            }
                        }
                        done({ "status": 200, "err_field": "", "message": "Success","data":cart_data });
                    });
               }else{
                done({ "status": 400, "err_field": "", "message": "No records found" });
               }
            }
        });
    },
    getMyCartItemsSessionUserId:function(user_id,session_id,done){
        cart.getCartItemsByUserIdSessionId(user_id,session_id,function (err, cart_data) {
            if(err){
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
            }else{
               if(cart_data.length > 0){
                    var product_ids_arr = [];var sku_arr = [];
                    for(var i in cart_data){
                        cart_data[i].sku = [];
                        product_ids_arr.push(cart_data[i].product_id);
                        sku_arr.push(cart_data[i].product_sku_id);
                    }
                    var product_ids = product_ids_arr.join(',');
                    var sku_ids = sku_arr.join(',');
                    var reqParamsObj = {product_id:product_ids,sku_ids:sku_ids}
                    productsSkuDAO.getProductSkuByProductIdAndSkuId(reqParamsObj,function (err, sku_data){
                        if(!err){
                            if(sku_data.length > 0){
                                for(var j in sku_data){
                                    for(var i in cart_data){
                                        if(cart_data[i].product_id == sku_data[j].product_id && sku_data[j].skid == cart_data[i].product_sku_id){
                                            sku_data[j].mycart = cart_data[i].quantity;
                                            cart_data[i].sku.push(sku_data[j]);
                                            delete cart_data[i].quantity;
                                        }
                                    }
                                }
                            }
                        }
                        done({ "status": 200, "err_field": "", "message": "Success","data":cart_data });
                    });
               }else{
                done({ "status": 400, "err_field": "", "message": "No records found" });
               }
            }
        });
    },
    clearMyCartItems:function(user_id,done){
        cart.deleteCartItemsByUserId(user_id,function (err, cart_data) {
            if(err){
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
            }else{
                done({ "status": 200, "err_field": "", "message": "Success","data_message":"Successfully cleared" });
            }
        });
    },
    clearMyCartItemByProduct:function(user_id,obj,done){
        cart.clearMyCartItemByProduct(user_id,obj,function (err, cart_data) {
            if(err){
                console.log(err);
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " });
            }else{
                done({ "status": 200, "err_field": "", "message": "Success","data_message":"Successfully cleared" });
            }
        });
    },
    addMyCartItems:function(user_id,session_id,user_data,done){
        if(
            common.gNUE(user_data.product_id) === '' || 
            common.gNUE(user_data.quantity) === '' || 
            common.gNUE(user_data.product_sku_id) === ''  
        ){
            done({ "status": 400, "message": "Required field is missing" });
        }else{
            cart.checkMyCartItems(user_id,session_id,user_data,function (err, cart_data) {
                if(err){
                    done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
                }else if(cart_data.length == 0){
                    cart.addMyCartItems(user_id,session_id,user_data,function (err, cart_data) {
                        if(err){
                            done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
                        }else{
                            done({ "status": 200, "err_field": "", "message": "Success","data_message":"Successfully added to cart" });
                        }
                    });
                }else{
                    done({ "status": 400, "err_field": "", "message": "Already added to cart"});
                }
            });
        }
    },
    updateMyCartItems:function(user_id,session_id,user_data,done){
        if(
            common.gNUE(user_data.product_id) === '' || 
            common.gNUE(user_data.quantity) === '' || 
            common.gNUE(user_data.product_sku_id) === ''  
        ){
            done({ "status": 400, "message": "Required field is missing" });
        }else if(user_data.quantity > 0){
            done({ "status": 400, "message": "Quantity should be more than 0" });
        }else{
            cart.updateMyCartItems(user_id,session_id,user_data,function (err, cart_data) {
                if(err){
                    done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
                }else{
                    done({ "status": 200, "err_field": "", "message": "Success","data_message":"Successfully updated to cart" });
                }
            });
        }
    },
    calculateCartSummary : function(results,done){
        var summary = {
            "cart_count": 0,
            "realization": "0",
            "mrp": 0,
            "selling_price": 0,
            "delivery_charge": 0,
            "grand_total": 0
        };

        if (results.status == 200) {
            summaryData = results.data;
            var actual_price = 0; var offer_price = 0;
            for (var i in summaryData) {
                var product_sku_id = summaryData[i].product_sku_id;
                var quantity = summaryData[i].quantity;
                for (var j in summaryData[i].sku) {
                    var skudata = summaryData[i].sku[j];
                    if(product_sku_id == skudata.skid){
                        actual_price += skudata.mycart * skudata.actual_price;
                        offer_price += skudata.mycart * skudata.offer_price;
                    }
                }
            }
            var delivery_charge = 50;
            var grand_total = delivery_charge + offer_price;
            summary = {
                "cart_count": summaryData.length,
                "realization": "0",
                "mrp": actual_price,
                "selling_price": offer_price,
                "delivery_charge": delivery_charge,
                "grand_total": grand_total
            };
        }
        done(summary);
    },
    updateSessionToUser:function(u_id,session_id,done){
        cart.updateSessionToUser(u_id,session_id,function(err,resp){

        });
    }
};
module.exports = cartService;