//reference of dbconnection.js
var users = require('../dao/userDAO');
var userAddress = require('../dao/userAddressDAO');
//var moment = require("moment");
const common = require('../common');
/*
var multer = require('multer');
var storage = multer.diskStorage({
    destination: function(req, file, callback) {
        var uplLoc = 'public/uploads/profile-images';
        if (!fs.existsSync(uplLoc)) {
            fs.mkdirSync(uplLoc);
        }
        callback(null, uplLoc);
    }, filename: function(req, file, callback) {
        console.log("file.originalname ",file.originalname);
        callback(null, file.originalname);
    }
});
var upload = multer({storage: storage}).single('profile_img');
*/
var usersService = {
    getAllMyAddress: function (decodedToken,callback) {
        userAddress.getAllMyAddress(decodedToken,function (err, address_data) {
            if(err){
                callback({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
               if(address_data.length>0){
                callback({ "status": 200, "err_field": "", "message": "Success","data":address_data });
               }else{
                callback({ "status": 400, "err_field": "", "message": "No records found" });
               }
            }
        });
    },
    getMyProfile: function (decodedToken,callback) {
        users.getUserById(decodedToken.u_id,function (err, address_data) {
            if(err){
                callback({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
               if(address_data.length>0){
                callback({ "status": 200, "err_field": "", "message": "Success","data":address_data });
               }else{
                callback({ "status": 400, "err_field": "", "message": "No records found" });
               }
            }
        });
    },
    addAddressByUser:function(decodedToken,user_data,callback){
        if(
            common.gNUE(user_data.ua_first_name) === '' || 
            common.gNUE(user_data.ua_last_name) === '' || 
            common.gNUE(user_data.ua_mobile_number) === '' || 
            common.gNUE(user_data.ua_city) === '' || 
            common.gNUE(user_data.ua_house_no) === '' || 
            common.gNUE(user_data.ua_area_details) === '' || 
            common.gNUE(user_data.ua_pincode) === ''    
        ){
            callback({ "status": 400, "message": "Required field is missing" });
        }else{
            user_data.user_id = decodedToken.u_id;
            //user_data.ua_updated_on = moment().format();
            //user_data.ua_created_on = moment().format();
            user_data.ua_status = 1;
            userAddress.addMyAddress(user_data,function(err,resp){
                if(err){
                callback({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
                }else{
                callback({ "status": 200, "err_field": "", "message": "Success","data":"Successfully added new address" });
                }
            });
        }
    },
    updateAddressByAddressId:function(decodedToken,user_data,callback){
        if(
            common.gNUE(user_data.ua_id) === '' || 
            common.gNUE(user_data.ua_first_name) === '' || 
            common.gNUE(user_data.ua_last_name) === '' || 
            common.gNUE(user_data.ua_mobile_number) === '' || 
            common.gNUE(user_data.ua_city) === '' || 
            common.gNUE(user_data.ua_house_no) === '' || 
            common.gNUE(user_data.ua_area_details) === '' || 
            common.gNUE(user_data.ua_pincode) === ''    
        ){
            callback({ "status": 400, "message": "Required field is missing" });
        }else{
            user_data.user_id = decodedToken.u_id;
            //user_data.ua_updated_on = moment().format();
            userAddress.updateAddressByAddressId(user_data,function(err,resp){
                if(err){
                callback({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
                }else{
                callback({ "status": 200, "err_field": "", "message": "Success","data":"Successfully updated the address" });
                }
            });
        }
    },
    uploadprofilePic:function(req,res,decodedToken,profileimg,done){
        if(req.files.profile_img){
            sampleFile = profileimg.profile_img;
            if(sampleFile.mimetype=='image/jpeg' || sampleFile.mimetype=='image/jpg' || sampleFile.mimetype=='image/png'){
                var profile_img_name = common.random_an(10);
                if(sampleFile.mimetype=='image/jpeg') profile_img_name=profile_img_name+".jpeg";
                if(sampleFile.mimetype=='image/jpg') profile_img_name=profile_img_name+".jpg";
                if(sampleFile.mimetype=='image/png') profile_img_name=profile_img_name+".png";
                profile_img_name = '/uploads/profile-images/' + profile_img_name;
                // Use the mv() method to place the file given path on your server

                async.series([
                    function(completed){
                        sampleFile.mv('public'+profile_img_name, function(err) {
                            if(err){
                                console.log(err);
                                done({ "status": 400, "err_field": "", "message": "Something went Wrong plepproduce try again"});
                            }else{
                                completed(null,profile_img_name);
                            }
                        });
                    }
                ], function (err, results) {
                    console.log(results);
                });

            }else{
                done({ "status": 400, "err_field": "", "message": "Invalid file format, Allows only jpeg,jpg and png"});
            }
        }else{
            done({ "status": 400, "err_field": "", "message": "No profile image is found"});
        }
    },
    uploadProfileData:function(decodedToken,user_data,done){
        console.log(user_data);
        if(
            common.gNUE(user_data.first_name) === '' || 
            common.gNUE(user_data.last_name) === '' || 
            common.gNUE(user_data.email) === '' || 
            common.gNUE(user_data.phone) === ''   
        ){
            done({ "status": 400, "message": "Required field is missing" });
        }else{
            user_data.user_id = decodedToken.u_id;
            //user_data.updated_on = moment().format();
            users.uploadProfileData(user_data,function(err,resp){
                if(err){
                    done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin " + err });
                }else{
                    done({ "status": 200, "err_field": "", "message": "Success","data":"Successfully updated profile" });
                }
            });
        }
    }
};
module.exports = usersService;