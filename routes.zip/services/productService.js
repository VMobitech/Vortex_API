//reference of dbconnection.js
var productsDAO = require('../dao/productDAO');
var productsSkuDAO = require('../dao/skuDAO');
var productSpecificationDAO = require('../dao/productSpecificationDAO');
var productImagesDAO = require('../dao/productImagesDAO');
var cartDAO = require('../dao/cartDAO');
var cartService = require('../services/cartService');
const common = require('../common');

var async = require('async');

var productsService = {
    //All categories list
    getAllProducts: function (limit,done) {
        if(limit == undefined){
            limit = '';
        }
        productsDAO.getAllProducts(limit,function (err, product_data) {
            if(err){
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
               if(product_data.length>0){
                done({ "status": 200, "err_field": "", "message": "Success","products":product_data });
               }else{
                done({ "status": 400, "err_field": "", "message": "No records found" });
               }
            }
        });
    },
    getProductDetailsWithDetail:function(productsList,product_ids,otherParams,done){
        var data = {products:[]};
        var skuids =  common.gNUE(otherParams.skuids);
        async.parallel([
            function(completed){

                var pushSkuData = function(sku_data){
                    if(sku_data.length > 0){
                        for(var j in sku_data){
                            for(var i in productsList){
                                if(productsList[i].id == sku_data[j].product_id){
                                    productsList[i].sku.push(sku_data[j]);
                                }
                            }
                        }
                    }
                    data.products = productsList;
                    completed(null,data);
                };

                if(skuids == ''){
                    productsSkuDAO.getProductSkuByProductId(product_ids,function (err, sku_data) {
                        if(!err){
                            pushSkuData(sku_data);
                        }
                    });
                }else{
                    var reqParamsObj = {product_id:product_ids,sku_ids:skuids};
                    productsSkuDAO.getProductSkuByProductIdAndSkuId(reqParamsObj,function (err, sku_data) {
                        if(!err){
                            pushSkuData(sku_data);
                        }
                    });
                }
            },
            function(completed){
                productSpecificationDAO.getProductSpecificationsByProductId(product_ids,function (err, specs_data) {
                    if(!err){
                        if(specs_data.length > 0){
                            for(var j in specs_data){
                                for(var i in productsList){
                                    if(productsList[i].id == specs_data[j].product_id){
                                        productsList[i].specs.push(specs_data[j]);
                                    }
                                }
                            }
                        }
                    }
                    data.products = productsList;
                    completed(null,data);
                });
            },
            function(completed){
                productImagesDAO.getProductImagesByProductId(product_ids,function (err, images_data) {
                    if(!err){
                        if(images_data.length > 0){
                            for(var j in images_data){
                                for(var i in productsList){
                                    if(productsList[i].id == images_data[j].product_id){
                                        productsList[i].pic.push(images_data[j]);
                                    }
                                }
                            }
                        }
                    }
                    data.products = productsList;
                    completed(null,data);
                });
            }
        ], function (err, results) {
            done(data);
        });
    },
    getProductsWithDetail:function(done){
        var this_ = (this);var limit = 10;
        this_.getAllProducts(limit,function(data){
            if(data.status === 200){
                var productsList =  data.products;var product_id_arr = [];
                for(var i in productsList){
                    product_id_arr.push(productsList[i].id);
                    productsList[i].sku = [];
                    productsList[i].specs = [];
                    productsList[i].pic = [];
                }
                var product_ids = product_id_arr.join(',');
                this_.getProductDetailsWithDetail(productsList,product_ids,{},function(resData){
                    data.products = resData.products;
                    done(data);
                });
            }else{
                done(data);
            }
        });
    },
    getProductById:function(reqObj,done){
        var this_ = (this);
        productsDAO.getProductById(reqObj,function(err,product_data){
            if(err){
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
                if(product_data.length>0){
                    var productsList =  product_data;var product_id_arr = [];
                    for(var i in productsList){
                        product_id_arr.push(productsList[i].id);
                        productsList[i].sku = [];
                        productsList[i].specs = [];
                        productsList[i].pic = [];
                    }
                    var product_ids = product_id_arr.join(',');
                    this_.getProductDetailsWithDetail(productsList,product_ids,{},function(resData){
                        productsList = resData.products;
                        done({ "status": 200, "err_field": "", "message": "Success","products":productsList });
                    });
                }else{
                    done({ "status": 400, "err_field": "", "message": "No records found" });
                }
            }
        });
    },
    getProductsBySubcategoryId:function(reqObj,done){
        var this_ = (this);
        productsDAO.getSubCategoryProducts(reqObj,function(err,product_data){
            if(err){
                console.log(err);
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin"});
            }else{
                if(product_data.length>0){
                    var productsList = product_data;var product_id_arr = [];
                    for(var i in productsList){
                        product_id_arr.push(productsList[i].id);
                        delete productsList[i]['sku'];
                        productsList[i].sku = [];
                        productsList[i].specs = [];
                        productsList[i].pic = [];
                    }
                    var product_ids = product_id_arr.join(',');
                    this_.getProductDetailsWithDetail(productsList,product_ids,{},function(resData){
                        productsList = resData.products;
                        
                        if(reqObj.sortType == 'plh' || reqObj.sortType == 'phl'){
                            productsList = formSKUWiceProducts({productsList:productsList});
                        }

                        done({ "status": 200, "err_field": "", "message": "Success","products":productsList });
                    });
                }else{
                    done({ "status": 400, "err_field": "", "message": "No records found" });
                }
            }
        });
    },
    getRefineProductsBySubcategoryId:function(reqObj,done){
        var this_ = (this);
        productsDAO.getRefineProductsBySubcategoryId(reqObj,function(err,product_data){
            if(err){
                console.log(err);
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin"});
            }else{
                if(product_data.length>0){
                    var productsList = product_data;var product_id_arr = [];var skid_arr = [];
                    for(var i in productsList){
                        product_id_arr.push(productsList[i].id);
                        skid_arr.push(productsList[i].skid);
                        delete productsList[i]['sku'];
                        productsList[i].sku = [];
                        productsList[i].specs = [];
                        productsList[i].pic = [];
                    }
                    var product_ids = product_id_arr.join(',');
                    var skuids = skid_arr.join(',');
                    this_.getProductDetailsWithDetail(productsList,product_ids,{skuids:skuids},function(resData){
                        productsList = resData.products;
                        productsList = formSKUWiceProducts({productsList:productsList});
                        done({ "status": 200, "err_field": "", "message": "Success","products":productsList });
                    });
                }else{
                    done({ "status": 400, "err_field": "", "message": "No records found" });
                }
            }
        });
    },
    checkIsCartProducts:function(request,OtherParameters,done){
        var products = OtherParameters.products;
        for(let i in products){
            for(let j in products[i].sku){
                products[i].sku[j].mycart = 0;
            }
        }
        common.check_token(request,function(decoded){
            var user_id = '';
            if(decoded.status == 200){
                user_id = decoded.decoded.u_id;
            }else{
                //user_id = user_data.session_id;
                user_id = request.headers.session_id;
            }
            var session_id = request.headers.session_id;
            if(common.gNUE(user_id) != '' || common.gNUE(session_id) != ''){

                cartDAO.getCartlistByUserSessionId(user_id,session_id, function (err,cart_data) {
                    if(!err){
                        if(cart_data.length != 0){
                            for(let i in products){
                                for(let j in products[i].sku){
                                    for(let k in cart_data){
                                        if(products[i].id == cart_data[k].product_id && 
                                            products[i].sku[j].skid == cart_data[k].product_sku_id
                                        ){
                                            products[i].sku[j].mycart = cart_data[k].quantity;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    done(products);
                });
            }else{
                done(products);
            }
        });
    }
};

function formSKUWiceProducts(prodObj){
    var productsList = prodObj.productsList;
    for(var i in productsList){
        for(var j in productsList[i].sku){
            if(productsList[i].sku[j].skid != productsList[i].skid){
                productsList[i].sku.splice(j, 1);
            }
        }
    }
    
    var productsFinal = []; var finalProductIds = [];
    for(var i in productsList){
        if(finalProductIds.indexOf(productsList[i].id) == -1 ){
            productsFinal.push(productsList[i]);
            finalProductIds.push(productsList[i].id);
        }else{
            for(var j in productsFinal){
                if(productsFinal[j].id == productsList[i].id){
                    for(var k in productsList[i].sku){
                        productsFinal[j].sku.push(productsList[i].sku[k]);
                    }
                }
            }
        }
    }
    for(var i in productsList){
        delete productsList[i]['skid'];
    }
    return productsFinal;
}

module.exports = productsService;
