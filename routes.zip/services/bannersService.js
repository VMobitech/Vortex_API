var bannersDAO = require('../dao/bannersDAO');

var bannersService = {
    //All banners list
    getAllbanners: function (done) {
       
        bannersDAO.getAllbanners(function (err, banners_data_res) {
            var banners_data={"TOP1":[],"TOP2":[],"TOP3":[],"TOP4":[],"TOP5":[],"OFFERS":[]};
            if(err){
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
                if(banners_data_res.length>0){
                    for(var i in banners_data_res){
                       /* banners_data[i].target = "1003135, 1003175, 1003140";
                        banners_data[i].sequence = "100";*/
                        
                        if(banners_data_res[i].banner_position=='TOP1')
                        {
                            banners_data.TOP1.push(banners_data_res[i])
                           
                           
                        }else if(banners_data_res[i].banner_position=='TOP2')
                        {
                           banners_data.TOP2.push(banners_data_res[i])
                           
                        }else if(banners_data_res[i].banner_position=='TOP3')
                        {
                            banners_data.TOP3.push(banners_data_res[i])
                        }else if(banners_data_res[i].banner_position=='TOP4')
                        {
                            banners_data.TOP4.push(banners_data_res[i])
                        }else if(banners_data_res[i].banner_position=='TOP5')
                        {
                            banners_data.TOP5.push(banners_data_res[i])
                        }else if(banners_data_res[i].banner_position=='OFFERS')
                        {
                            banners_data.OFFERS.push(banners_data_res[i])
                        }
                        
                    }
                    done({ "status": 200, "err_field": "", "message": "Success",result:banners_data });
                }else{
                    done({ "status": 400, "err_field": "", "message": "No records found",result:[] });
                }
            }
        });
    },
    getAllbannersWithLimit : function(start,limit,done){
        bannersDAO.getAllbannersWithLimit(start,limit,function (err, banners_data) {
            if(err){
                done({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
                if(banners_data.length>0){
                    for(var i in banners_data){
                        banners_data[i].target = "1003135, 1003175, 1003140";
                        banners_data[i].sequence = "100";
                    }
                    done({ "status": 200, "err_field": "", "message": "Success",result:banners_data });
                }else{
                    done({ "status": 400, "err_field": "", "message": "No records found" });
                }
            }
        });
    }
};
module.exports = bannersService;