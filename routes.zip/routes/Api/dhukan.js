var express = require('express');
var router = express.Router();
var categories = require('../../modal/categoryModal');
var products = require('../../modal/productModal');
var categoryDAO = require('../../dao/categoryDAO');
var productDAO = require('../../dao/productDAO');
var productService = require('../../services/productService');
var categoryService = require('../../services/categoryService');
var bannersService = require('../../services/bannersService');
var utils = require('../../modal/utilsModal');
var utils = require('../../dao/utilsDAO');
var dateTime = require('node-datetime');
var dt = dateTime.create();
var formatted = dt.format('Y-m-d H:M:S');
//var bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
const config = require('../../config/config');
const common = require('../../common');

router.get('/', function (req, res, next) {
    res.send('respond with a resource');
});

// get all categories
router.get("/categories", function(req,res){
    /*categoryDAO.getAllCategories(function (err, category_data) {
        if (err) {
            res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
        } else {
            if(category_data.length>0){
                res.status(200).json({ "status": 200, "err_field": "", "message": "Success","categories":category_data });
            }else{
                res.status(200).json({ "status": 400, "err_field": "", "message": "No records found" });
            }
        }
    });*/
    categoryService.getAllCategoriesDetail(function (data) {
        res.status(data.status).json(data);
    });
});

// get specific category information
router.get("/category/:id",function(req,res){
    var id=req.params.id;
    if(!id){
        res.status(200).json({"status":400,"message":"Please provide category id","error_field":"id"});
    }else{
        categoryService.getCategoryById(id,function (data) {
            data.categoryinfo = data.categoryinfo[0];
            res.status(200).json(data);
        });
      }
});

// get all products
router.get("/products",function(req,res){
    productService.getProductsWithDetail(function (data) {
        if(data.status == 200){
            var paramsobj = {products:data.products};
            productService.checkIsCartProducts(req,paramsobj,function(cartData){
                data.products = cartData;
                res.status(200).json(data);
            });
        }else{
            res.status(data.status).json(data);
        }
    });
    /*productDAO.getAllProducts(function (err, product_data) {
        if(err){
            res.status(400).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
        }else{
            if(product_data.length>0){
                res.status(200).json({ "status": 200, "err_field": "", "message": "Success","products":product_data });
            }else{
                res.status(200).json({ "status": 400, "err_field": "", "message": "No records found" });  
            }
        }
    });*/
});

// get specific product information
router.get("/product/:id",function(req,res){
    var id = common.gNUE(req.params.id);
    if(id == ''){
        res.status(200).json({"status":400,"message":"Please provide category id","error_field":"id"});
    }else{
        productService.getProductById({product_id:id},function(data){
            if(data.status == 200){
                var paramsobj = {products:data.products};
                productService.checkIsCartProducts(req,paramsobj,function(cartData){
                    data.products = cartData;
                    res.status(200).json(data);
                });
            }else{
                res.status(data.status).json(data);
            }
            //res.status(data.status).json(data);
        });
        /*productDAO.getProductById(id, function (err, product_data) {
            if(err){
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
                if(product_data.length>0){
                    res.status(200).json({ "status": 200, "err_field": "", "message": "Success","productinfo":product_data });
                }else{
                    res.status(200).json({ "status": 400, "err_field": "", "message": "No records found" });
                }
            }
        });*/
    }
});

// get all products for a specific category
router.get("/catproducts/:id",function(req,res){
    var categoryid = req.params.id;
    if(categoryid){
        categoryDAO.getCategoryProducts(categoryid, function (err, product_data) {
            if(err){
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
                if(product_data.length>0){
                    var prodArr = [];
                    for(var i in product_data){
                        if(prodArr.indexOf(product_data[i].id) == -1){
                            prodArr.push(product_data[i].id);
                        }
                    }
                    var podIds = prodArr.join(',');
                    productService.getProductById({product_id:podIds},function (data) {
                        if(data.status == 200){
                            var paramsobj = {products:data.products};
                            productService.checkIsCartProducts(req,paramsobj,function(cartData){
                                data.products = cartData;
                                res.status(data.status).json(data);
                            });
                        }else{
                            res.status(200).json(data);
                        }
                    });
                }else{
                    res.status(200).json({ "status": 400, "err_field": "", "message": "No records found" });  
                }
            }
        });
    }else{
        res.status(400).json({"status":400,"message":"Please provide category id","error_field":"id"});
    }
});

router.post("/subcatproducts/:id",function(req,res){
    var sub_category_id = common.gNUE(req.params.id);
    if(sub_category_id == ''){
        res.status(200).json({ "status": 400, "err_field": "", "message": "Please Provide Sub category Id"});
    }else{
        var reqdata = req.body;
        var sortType = "";// "alphabetical";
        var sort = 'desc';var limit=10;var limit_from = 0;var search_string = "";
        if(common.gNUE(reqdata.sortType) != ''){
            sortType = reqdata.sortType;
        }
        if(common.gNUE(reqdata.sort) != ''){
            sort = reqdata.sort;
        }
        if(common.gNUE(reqdata.limit) != ''){
            limit = reqdata.limit;
        }
        if(common.gNUE(reqdata.limit_from) != ''){
            limit_from = reqdata.limit_from;
        }
        if(common.gNUE(reqdata.search_string) != ''){
            search_string = reqdata.search_string;
        }
        
        var reqObj = {sub_category_id:sub_category_id,limit:limit,limit_from:limit_from,sort:sort,sortType:sortType,search_string:search_string};
        productService.getProductsBySubcategoryId(reqObj,function(data){
            if(data.status == 200){
                var paramsobj = {products:data.products};
                productService.checkIsCartProducts(req,paramsobj,function(cartData){
                    data.products = cartData;
                    res.status(data.status).json(data);
                });
            }else{
                res.status(data.status).json(data);
            }
        });
    }
});

router.post("/refineSubcatProducts/:id",function(req,res){
    var sub_category_id = common.gNUE(req.params.id);
    if(sub_category_id == ''){
        res.status(200).json({ "status": 400, "err_field": "", "message": "Please Provide Sub category Id"});
    }else{
        var reqdata = req.body;
        var sortType = "";// "alphabetical";
        var sort = 'desc';var limit=10;var limit_from = 0;
        var brand_id = "";var price_from = '';var price_to = '';var discount = "";var search_string = "";
        if(common.gNUE(reqdata.sort) != ''){
            sort = reqdata.sort;
        }
        if(common.gNUE(reqdata.limit) != ''){
            limit = reqdata.limit;
        }
        if(common.gNUE(reqdata.limit_from) != ''){
            limit_from = reqdata.limit_from;
        }
        if(common.gNUE(reqdata.brand_id) != ''){
            brand_id = reqdata.brand_id;
        }
        if(common.gNUE(reqdata.price_from) != ''){
            price_from = reqdata.price_from;
        }
        if(common.gNUE(reqdata.price_to) != ''){
            price_to = reqdata.price_to;
        }
        if(common.gNUE(reqdata.discount) != ''){
            discount = reqdata.discount;
        }
        if(common.gNUE(reqdata.search_string) != ''){
            search_string = reqdata.search_string;
        }
        
        var reqObj = {sub_category_id:sub_category_id,limit:limit,limit_from:limit_from,sort:sort,brand_id:brand_id,price_from:price_from,price_to:price_to,discount:discount,search_string:search_string};
        productService.getRefineProductsBySubcategoryId(reqObj,function(data){
            if(data.status == 200){
                var paramsobj = {products:data.products};
                productService.checkIsCartProducts(req,paramsobj,function(cartData){
                    data.products = cartData;
                    res.status(data.status).json(data);
                });
            }else{
                res.status(data.status).json(data);
            }
        });
    }
});

router.post("/searchproducts",function(req,res){
    var reqdata = req.body;
    if(common.gNUE(reqdata.search_string) != ''){
        var sortType = "";// "alphabetical";
        var sort = 'desc';var limit=10;var limit_from = 0;var search_string = "";
        var brand_id = "";
        if(common.gNUE(reqdata.sortType) != ''){
            sortType = reqdata.sortType;
        }
        if(common.gNUE(reqdata.sort) != ''){
            sort = reqdata.sort;
        }
        if(common.gNUE(reqdata.limit) != ''){
            limit = reqdata.limit;
        }
        if(common.gNUE(reqdata.limit_from) != ''){
            limit_from = reqdata.limit_from;
        }

        if(common.gNUE(reqdata.search_string) != ''){
            search_string = reqdata.search_string;
        }
        
        var reqObj = {limit:limit,limit_from:limit_from,sort:sort,sortType:sortType,search_string:search_string};
        productService.getProductsBySubcategoryId(reqObj,function(data){
            if(data.status == 200){
                var paramsobj = {products:data.products};
                productService.checkIsCartProducts(req,paramsobj,function(cartData){
                    data.products = cartData;
                    res.status(data.status).json(data);
                });
            }else{
                res.status(data.status).json(data);
            }
        });
    }else{
        res.status(200).json({"status":400,"message":"Please provide search keyword","error_field":"search_string"});
    }
});

// search by product name keyword
router.get("/prdsrc/:productname",function(req,res){
    var search_string = req.params.productname;
    if(search_string != ""){
        utils.searchProductByName(search_string, function (err, product_data) {
            if(err){
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" });
            }else{
                if(product_data.length>0){
                    var prodArr = [];
                    for(var i in product_data){
                        if(prodArr.indexOf(product_data[i].id) == -1){
                            prodArr.push(product_data[i].id);
                        }
                        var podIds = prodArr.join(',');
                        productService.getProductById({product_id:podIds},function (data) {
                            if(data.status == 200){
                                var paramsobj = {products:data.products};
                                productService.checkIsCartProducts(req,paramsobj,function(cartData){
                                    data.products = cartData;
                                    res.status(data.status).json(data);
                                });
                            }else{
                                res.status(data.status).json(data);
                            }
                        });
                    }
                    //res.status(200).json({ "status": 200, "err_field": "", "message": "Success","products":product_data });
                }else{
                    res.status(200).json({ "status": 400, "err_field": "", "message": "No records found" });  
                }
            }
        });
    }else{
        res.status(200).json({"status":400,"message":"Please provide search keyword","error_field":"keyword"});
    }
});

// search products based on category name keyword
router.get("/catprdsrc/:catname",function(req,res){
    var search_string = req.params.catname;
    if(search_string != ""){
        utils.searchProductsByCatName(search_string, function (err, product_data) {
            if(err){
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            }else{
                if(product_data.length>0){
                    var prodArr = [];
                    for(var i in product_data){
                        if(prodArr.indexOf(product_data[i].id) == -1){
                            prodArr.push(product_data[i].id);
                        }
                        var podIds = prodArr.join(',');
                        productService.getProductById({product_id:podIds},function (data) {
                            if(data.status == 200){
                                var paramsobj = {products:data.products};
                                productService.checkIsCartProducts(req,paramsobj,function(cartData){
                                    data.products = cartData;
                                    res.status(data.status).json(data);
                                });
                            }else{
                                res.status(data.status).json(data);
                            }
                        });
                    }
                    //res.status(200).json({ "status": 200, "err_field": "", "message": "Success","products":product_data });
                }else{
                    res.status(200).json({ "status": 400, "err_field": "", "message": "No records found" });  
                }
            }
        }); 
    }else{
        res.status(200).json({"status":400,"message":"Please provide search keyword","error_field":"keyword"});
    }
});

// get all products
router.get("/productsList",function(req,res){
	var limit = 10;
    productService.getAllProducts(limit,function (product_data) {
        res.status(product_data.status).json(product_data);
    });

});

// get all products
router.post("/categories-list",function(req,res){
    categoryService.categoriesList(req,function (product_data) {
        res.status(200).json(product_data);
    });
});

module.exports = router;
