var express = require('express');
var router = express.Router();
var Users = require('../../dao/userDAO');
var dateTime = require('node-datetime');
var dt = dateTime.create();
var formatted = dt.format('Y-m-d H:M:S');
//var bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
const config = require('../../config/config');
const common = require('../../common');
var usersService = require('../../services/usersService');
var cartService = require('../../services/cartService');
var categoryService = require('../../services/categoryService');
var productService = require('../../services/productService');
var bannersService = require('../../services/bannersService');
var db = require('../../config/dbconnection'); 
function randomstring(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for(var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}

function token_create(payload) {
    var token = jwt.sign(payload, config.secret);
    return token
}

//router.use(require('./tokenChecker'))


router.get("/",function(req,res){
    var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //user_id = user_data.session_id;
            user_id = req.headers.session_id;
        }

        var session_id = req.headers.session_id;

        if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
            var obj = {user_id:user_id,session_id:session_id};
            cartService.getMyCartItemsSessionUserId(user_id,session_id, function (cartdata) {
                cartService.calculateCartSummary(cartdata,function(summary){
                    summary = summary;
                    categoryService.getAllCategoriesDetail_dashbord(function (catergoriesdata) {
                         productService.getProductsWithDetail(function (productdata) {
        if(productdata.status == 200){
              bannersService.getAllbanners(function (bannerdata) {
        // var paramsobj = {products:productdata.products};
            // productService.checkIsCartProducts(req,paramsobj,function(productdata){
                // productdata.products = cartData;
                        var data = {};
data.categories = catergoriesdata;
data.cart = summary;
data.products=productdata.products;
data.offer=bannerdata.result;
data.image_path="http://versatilemobitech.co.in/DHUKAN/images/";
data.status=productdata.status;


                       
        res.status(200).json(data);
        //   res.status(data.status).json("data");
              })
            // });
        
        }else{
            res.status(200).json(data);
        }
    });
    });
                    // res.status(data.status).json(data);  
                })
            });
        }
    });
});

router.post("/checkout", function(req,res){
      var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //user_id = user_data.session_id;
            user_id = req.headers.session_id;
        }

        var session_id = req.headers.session_id;

        if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
             console.log(user_id);
            // var obj = {user_id:user_id,session_id:session_id};
         
        var query = common.formInsertQuery({table_name:'orders',fields:req.body,type:'insert'});
        db.query(query);
        
        var cart_data= {};
         var obj = {user_id:user_id,session_id:session_id};
            cartService.getMyCartItemsSessionUserId(user_id,session_id, function (cartdata) {
                cartService.calculateCartSummary(cartdata,function(summary){
                     
                    cart_data.summary = summary;
                    cart_data.cartdata = cartdata
      
       
        // var order_lists =[];
        // for(i=0;i<cart_data.cartdata.data.lenght;i++)
        // {
            var order_item_data={};
              order_item_data.oid= req.body.order_id;
                  order_item_data.quantity= Number(cart_data.cartdata.data[0].sku[0].mycart);
                  order_item_data.product_id= Number(cart_data.cartdata.data[0].product_id);
                  order_item_data.sku_id= Number(cart_data.cartdata.data[0].sku[0].sku);
                    order_item_data.discount_by_price=Number(cart_data.cartdata.data[0].sku[0].actual_price - cart_data.cartdata.data[0].sku[0].selling_price);
                    //   console.log('data' +JSON.stringify(order_item_data));
                    // order_list.push(order_item_data);
                    
        // }
      
  
         var query_order = common.formInsertQuery({table_name:'order_items',fields:order_item_data,type:'insert'});
            //   console.log(query_order);
          db.query(query_order);
    
        res.status(200).json();  
                })
        })
        }
    });
    
})
router.get("/myorders", function(req,res){
     var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //user_id = user_data.session_id;
            user_id = req.headers.session_id;
        }

    if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
     var query = "SELECT * FROM `orders` where user_id = " + user_id +" AND payment_status = 'DONE'";
    //          console.log(query);
    //           getdata(query,function (err, data) {
                  
    //               res.status(200).json(err);   
    //           })
     db.query(query,function (err, result) {
    if (err){
         res.status(200).json({ "status": 400, "message": "Required field is missing" });
    }else{
    console.log(result);
    res.status(200).json({"status":200,"message":"success","data":result}); 
    }
  });
         
         
        }
    });
})

router.post("/payment", function(req,res){
      var user_data = req.body;
        common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //user_id = user_data.session_id;
            user_id = req.headers.session_id;
        }

        var session_id = req.headers.session_id;

        if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
           
            var obj = {user_id:user_id,session_id:session_id};
               cartService.clearMyCartItems(user_id, function (data) {
                // res.status(data.status).json(data);
        
             var query = "UPDATE `orders` SET `status`='DONE', `payment_status` ='DONE' where `order_id`=" + req.body.order_id;
              db.query(query,function (err, result) {
    if (err){ 
           res.status(200).json({"status":400,"message":"Something Wentwrong please tryagain"});  
    }else
    {
    console.log(result);
    res.status(200).json({"status":200,"message":"success"}); 
    }
  });
               });
            // cartService.getMyCartItemsSessionUserId(user_id,session_id, function (cartdata) {
            //     cartService.calculateCartSummary(cartdata,function(summary){
            //         cartdata.summary = summary;
            //          res.status(200).json(cartdata);
   
            //         // res.status(data.status).json(data);  
            //     })
            // });
        }
    });
    
})
router.get("/orderdetails/:order_id", function(req,res){
     var order_id = common.gNUE(req.params.order_id);
     console.log('order_id' + req.params.order_id)
     var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //user_id = user_data.session_id;
            user_id = req.headers.session_id;
        }

    if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
     var query = "SELECT * FROM `order_items` where oid = " + order_id ;
  
     db.query(query,function (err, result) {
    if (err) 
    {
        res.status(200).json({"status":400,"message":"Something Wentwrong please tryagain"});
        
    }else
    {
       console.log(result);
       res.status(200).json({"status":200,"message":"success","data":result}); 
    }
  });
         
         
        }
    });
    
})

module.exports = router;


