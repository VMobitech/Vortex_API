var express = require('express');
var router = express.Router();
var Users = require('../../dao/userDAO');
var dateTime = require('node-datetime');
var dt = dateTime.create();
var formatted = dt.format('Y-m-d H:M:S');
//var bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
const config = require('../../config/config');
const common = require('../../common');
var usersService = require('../../services/usersService');
var cartService = require('../../services/cartService');

/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('respond with a resource');
});

router.get("/locations/:id", function(req,res){

         var id=req.params.id;
    if(!id)
    {
        res.json({"status":400,"message":"Please provide country id","error_field":"id"});
    }else
    {
        Users.getAllLocations(id, function (err, location_data) {

            if (err) {
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            } else {
               
               if(location_data.length>0)
               {
                    res.status(200).json({ "status": 200, "err_field": "", "message": "Success","locations":location_data });

               }else
               {
                    res.status(200).json({ "status": 400, "err_field": "", "message": "No records found" });
                   
               }
                
            }
        
        })
    }
    
})

router.get("/pincodes/:id",function(req,res){

         var id=req.params.id;
    if(!id)
    {
        res.json({"status":400,"message":"Please provide country id","error_field":"id"});
    }else
    {
        Users.getAllPincodes(id, function (err, location_data) {

            if (err) {
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            } else {
               
               if(location_data.length>0)
               {
                    res.status(200).json({ "status": 200, "err_field": "", "message": "Success","locations":location_data });

               }else
               {
                    res.status(200).json({ "status": 400, "err_field": "", "message": "No records found" });
                   
               }
                
            }
        
        })
    }
    
})
router.post("/registration", function(req, res, next) {

    
    var user_input = {
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        email: req.body.email,
        phone: req.body.phone,
        password: req.body.password,
        user_status: 1,
        latitude: '',
        longitude: '',
        image: '',
        business_name: '',
        created_on: formatted,
        updated_on: '',
        login_type: 'DHUKAHAN',
        auth_key: '',
        refered_by: '',
        role: 'USER',
        referral_code: req.body.referral_code,
        is_used_referal: 'No'
    }
    var reqdata = user_input;
    var err_message = "";
    var err_field = "";
    var validate = true;
    if (!reqdata.first_name) {
        err_message = "Please provide First name";
        err_field = "first_name";
        validate = false;
    } else if (!reqdata.last_name) {
        err_message = "Please provide Last name";
        err_field = "last_name";
        validate = false;
    } else if (!reqdata.email) {
        err_message = "Please provide E-Mail";
        err_field = "email";
        validate = false;
    } else if (!reqdata.phone) {
        err_message = "Please provide Phone";
        err_field = "phone";
        validate = false;
    } else if (!reqdata.password) {
        err_message = "Please provide password";
        err_field = "password";
        validate = false;
    } else if (!req.body.device_id) {
        err_message = "Please provide device id";
        err_field = "device_id";
        validate = false;
    } else if (!req.body.device_token) {
        err_message = "Please provide device token";
        err_field = "device_token";
        validate = false;
    } else if (!req.body.device_type) {
        err_message = "Please provide device type";
        err_field = "device_type";
        validate = false;
    }

    if (validate && err_field == "") {
        //  check duplicate user
        Users.validate_user(reqdata.email, reqdata.phone, function (err, responce) {
            if (err) {
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });

            } else {

                if (responce.length > 0) {
                    res.status(200).json({ "status": 400, "err_field": "email,phone", "message": "Duplicvate Email,phone" });

                } else {
                    //encrypt password                               
                  //  reqdata.password = bcrypt.hashSync(reqdata.password, 10);
                    ///                
                    if (!reqdata.referral_code) {

                        reqdata.referral_code=randomstring(7);


                        Users.addUser(reqdata, function (err, data) {

                            if (err) {
                                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try again" + err });

                            } else {
                                if (data.insertId) {

                                    const payload = {
                                        u_id: data.insertId,
                                        type: "USER"
                                    };
                                    var token = token_create(payload);
                                    // do some operations
                                    res.status(200).json({ "status": 200, "err_field": "", "message": "Thank you for registering with us Welcome to DHUKHAN", "token": token, "u_id": data.insertId });

                                } else {
                                    res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try again" + err });
                                }
                            }
                        });
                    } else {
                        // referal code exit or not check                       
                        Users.verifyReferelcode(reqdata.referral_code, function (err, user_info) {
                            if (err) {
                                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try again" + err });
                            } else {
                                if (user_info.length > 0) {
                                    // add user with referal code
                                    reqdata.refered_by = user_info[0].u_id;
                                    reqdata.referral_code=randomstring(7);
                                    Users.addUser(reqdata, function (err, data) {
                                        if (err) {
                                            res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try again" + err });
                                        } else {
                                            if (data.insertId) {
                                                const payload = {
                                                    u_id: data.insertId,
                                                    type: "USER"
                                                };
                                                var token = token_create(payload);
                                                // do some operations
                                                res.status(200).json({ "status": 200, "err_field": "", "message": "Thank you for registering with us Welcome to DHUKHAN", "token": token, "u_id": data.insertId });
                                            } else {
                                                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try again" + err });
                                            }
                                        }
                                    });

                                } else {
                                    res.status(200).json({ "status": 400, "err_field": "", "message": "Invalid referal code" + err });
                                }
                            }
                        });
                        // console.log(Users.verifyReferelcode(reqdata.referral_code));
                    }
                }
            }
        })
    } else {
        res.status(200).json({ "status": 400, "err_field": err_field, "err_message": err_message });
    }
})

router.get("/token", function () {
    const payload = {
        admin: "mahesgh"
    };
})


// login service
router.post('/login', function(req, res) {

    var reqdata = req.body;
    var err_message = "";
    var err_field = "";
    var validate = true;
    if (!reqdata.phone) {
        err_message = "Please provide Mobile number";
        err_field = "phone";
        validate = false;
    } else if (!reqdata.password) {
        err_message = "Please provide Password";
        err_field = "password";
        validate = false;
    }
    if (validate && err_field == "") {

        Users.validate_user_login(reqdata.phone, function (err, user_data) {

            if (err) {
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            } else {
                if (user_data.length > 0) {
                    
                    if((reqdata.password==user_data[0].password))
                    {
                         const payload = {
                            u_id: user_data[0].u_id,
                            type: "USER"
                        };
                        var token = token_create(payload);
                        user_data[0].password = "";

                        res.status(200).json({ "status": 200, "err_field": "", "message": "Your loged in successfully", "data": user_data[0], "token": token });
                    }else
                    {
                       res.status(200).json({ "status": 400, "err_field": "password", "message": "Please Provide valida password" });

                        
                    }
                    
                    /*
                    if (bcrypt.compareSync(reqdata.password, user_data[0].password)) {

                        const payload = {
                            u_id: user_data[0].u_id,
                            type: "USER"
                        };
                        var token = token_create(payload);
                        user_data[0].password = "";


                        res.status(200).json({ "status": 200, "err_field": "", "message": "Your loged in successfully", "data": user_data[0], "token": token });

                    } else {
                        res.status(200).json({ "status": 400, "err_field": "password", "message": "Please Provide valida password" });

                    }
                    */

                } else {
                    res.status(200).json({ "status": 400, "err_field": "phone", "message": "Please Provide valida mobile number" });

                }
            }
        })
    } else {
        res.status(200).json({ "status": 400, "err_field": err_field, "err_message": err_message });
    }

})


router.post("/socialLogins", function (req, res) {

    var reqdata = req.body;
    var user_information = {
        first_name: (!reqdata.first_name) ? "" : reqdata.first_name,
        last_name: (!reqdata.last_name) ? "" : reqdata.last_name,
        email: (!reqdata.email) ? "" : reqdata.email,
        phone: (!reqdata.phone) ? "" : reqdata.phone,
        login_type: (!reqdata.login_type) ? "" : reqdata.login_type,
        auth_key: (!reqdata.auth_key) ? "" : reqdata.auth_key,
        status: 1
    }
    var err_message = "";
    var err_field = "";
    var validate = true;
    if (!reqdata.auth_key) {
        err_message = "Please provide Auth key";
        err_field = "auth_key";
        validate = false;
    } else if (!reqdata.login_type) {
        err_message = "Please provide Login type key words FACEBOOK or GOOGLEPLUS";
        err_field = "login_type";
        validate = false;
    }
    if (validate && err_field == "") {

        Users.validate_solial_login(reqdata.auth_key, function (err, user_data) {
            if (err) {
                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
            } else {
                if (user_data.length > 0) {
                    Users.updateUser(user_data[0].u_id, user_information, function (err, data) {
                        if (err) {
                            res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" + err });
                        } else {
                            if (data.affectedRows > 0) {
                                const payload = {
                                    u_id: user_data[0].u_id,
                                    type: "USER"
                                };
                                var token = token_create(payload);

                                res.status(200).json({ "status": 200, "err_field": "", "message": "Your loged in successfully","token":token,"data": user_data[0]});
                            } else {
                                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try agin" });

                            }
                        }
                    })

                } else {
                    user_information.referral_code=randomstring(7);

                    Users.addUser(user_information, function (err, data) {
                        if (err) {
                            res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try again" + err });

                        } else {
                            if (data.insertId) {

                                const payload = {
                                    u_id: data.insertId,
                                    type: "USER"
                                };
                                var token = token_create(payload);
                                // do some operations
                                
                                Users.validate_solial_login(reqdata.auth_key, function (err, user_data) {
                                    
                                    if(err)
                                    {
                                   res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try again" + err });

                                        
                                    }else
                                    {
                                
                                res.status(200).json({ "status": 200, "err_field": "", "message": "Thank you for registering with us Welcome to DHUKHAN", "token": token, "data": user_data[0] });

                            
                                }
                                })
                                } else {
                                res.status(200).json({ "status": 400, "err_field": "", "message": "something wentwrong please try again" + err });
                            }
                        }
                    });
                }

            }
        })
    } else {
        res.status(200).json({ "status": 400, "err_field": err_field, "err_message": err_message });
    }

})


router.post("/request_otp",function(req,res)
{
    var reqdata = req.body;
    var err_message = "";
    var err_field = "";
    var validate = true;
    if (!reqdata.phone) {
        err_message = "Please provide Mobile number";
        err_field = "phone";
        validate = false;
    }
    if(validate && err_field=="")
    {
                var otp=1234
        res.status(200).json({ "status": 200,  "message": "Succes", "otp":otp,"data":reqdata });        
    }else{
        res.status(200).json({ "status": 400, "err_field": err_field, "err_message": err_message });
    }    
})

 function randomstring(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for(var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}

function token_create(payload) {
    var token = jwt.sign(payload, config.secret);
    return token
}

//router.use(require('./tokenChecker'))


router.get("/my_address",common.verify_token,function(req,res){
    var token = req.headers.token;
    var decodedToken = req.decoded;
    if (token === undefined) {
        res.status(200).json({ "status": 400, "message": "Token not found" });
    } else {
        usersService.getAllMyAddress(decodedToken, function (data) {
            res.status(data.status).json(data);
        })
    }
});

router.get("/my_profile",common.verify_token,function(req,res){
    var token = req.headers.token;
    var decodedToken = req.decoded;
    if (token === undefined) {
        res.status(200).json({ "status": 400, "message": "Token not found" });
    } else {
        usersService.getMyProfile(decodedToken, function (data) {
            res.status(data.status).json(data);
        })
    }
});

router.post("/add_address",common.verify_token,function(req,res){
    var token = req.headers.token;
    var decodedToken = req.decoded;
    var user_data = req.body;
    if (token === undefined) {
        res.status(200).json({ "status": 400, "message": "Token not found" });
    } else {
        usersService.addAddressByUser(decodedToken,user_data, function (data) {
            res.status(200).json(data);
        })
    }
});

router.post("/update_address",common.verify_token,function(req,res){
    var token = req.headers.token;
    var decodedToken = req.decoded;
    var user_data = req.body;
    if (token === undefined) {
        res.status(200).json({ "status": 400, "message": "Token not found" });
    } else {
        usersService.updateAddressByAddressId(decodedToken,user_data, function (data) {
            res.status(200).json(data);
        })
    }
});

router.put("/profile_image",common.verify_token,function(req,res){
    var decodedToken = req.decoded;
    var profileimg = req.files;
    usersService.uploadprofilePic(req,res,decodedToken,profileimg, function (data) {
        res.status(200).json(data);
    })
});

router.put("/update_profile",common.verify_token,function(req,res){
    var decodedToken = req.decoded;
    var user_data = req.body;
    usersService.uploadProfileData(decodedToken,user_data, function (data) {
        res.status(200).json(data);
    })
});
module.exports = router;


