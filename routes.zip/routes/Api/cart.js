var express = require('express');
var router = express.Router();
var Users = require('../../dao/userDAO');
var dateTime = require('node-datetime');
var dt = dateTime.create();
var formatted = dt.format('Y-m-d H:M:S');
//var bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
const config = require('../../config/config');
const common = require('../../common');
var usersService = require('../../services/usersService');
var cartService = require('../../services/cartService');


 function randomstring(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for(var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}

function token_create(payload) {
    var token = jwt.sign(payload, config.secret);
    return token
}

//router.use(require('./tokenChecker'))

router.post("/my_cart_orders",function(req,res){
    var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            user_id = user_data.session_id;
        }

        if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
            cartService.getMyCartItems(user_id, function (data) {
                res.status(200).json(data);
            });
        }
    });
});

router.get("/cart-list",function(req,res){
    var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //user_id = user_data.session_id;
            user_id = req.headers.session_id;
        }

        var session_id = req.headers.session_id;

        if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
            var obj = {user_id:user_id,session_id:session_id};
            cartService.getMyCartItemsSessionUserId(user_id,session_id, function (data) {
                cartService.calculateCartSummary(data,function(summary){
                    data.summary = summary;
                    res.status(200).json(data);  
                })
            });
        }
    });
});


router.delete("/cart-list",function(req,res){
    var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //user_id = user_data.session_id;
            user_id = req.headers.session_id;
        }

        if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
            cartService.clearMyCartItems(user_id, function (data) {
                res.status(200).json(data);
            });
        }
    });
});

router.delete("/cart-list/:cart_id",function(req,res){
    var user_data = req.body;
    var cart_id = req.params.cart_id;
    common.check_token(req,function(decoded){
        var user_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //user_id = user_data.session_id;
            user_id = req.headers.session_id;
        }

        if(common.gNUE(user_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
            var obj = {cart_id:cart_id};
            cartService.clearMyCartItemByProduct(user_id,obj, function (data) {
                res.status(200).json(data);
            });
        }
    });
});

router.post("/cart-list",function(req,res){
    var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';var session_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //session_id = user_data.session_id;
            session_id = req.headers.session_id;
        }
        if(common.gNUE(user_id) == '' &&  common.gNUE(session_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
            cartService.addMyCartItems(user_id,session_id,user_data, function (data) {
                res.status(200).json(data);
            });
        }
    });
});

router.put("/cart-list",function(req,res){
    var user_data = req.body;
    common.check_token(req,function(decoded){
        var user_id = '';var session_id = '';
        if(decoded.status == 200){
            user_id = decoded.decoded.u_id;
        }else{
            //session_id = user_data.session_id;
            session_id = req.headers.session_id;
        }

        if(common.gNUE(user_id) == '' &&  common.gNUE(session_id) == ''){
            res.status(200).json({ "status": 400, "message": "Required field is missing" });
        }else{
            cartService.updateMyCartItems(user_id,session_id,user_data, function (data) {
                res.status(200).json(data);
            });
        }
    });
});

module.exports = router;


