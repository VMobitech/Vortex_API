var express = require('express');
var router = express.Router();
var Users = require('../../dao/userDAO');
var dateTime = require('node-datetime');
var dt = dateTime.create();
var formatted = dt.format('Y-m-d H:M:S');
//var bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
const config = require('../../config/config');
const common = require('../../common');
var bannersService = require('../../services/bannersService');

router.get("/banners-list",function(req,res){
    bannersService.getAllbanners(function (data) {
        //res.status(data.status).json(data);
        res.status(200).json(data);
    });
});

module.exports = router;


