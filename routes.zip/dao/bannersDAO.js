//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var banners = {
    //All banners list
    /**
     * 06-09-2018 6:24
     * target is where to navigate 
     * wheather product list or product details or some offer scree.
     * 
     */

    getAllbanners: function (callback) {
        return db.query("SELECT `id`, `name`, `pic`, `pic_web`, `type`,target,sequence,banner_position FROM `banners` order by id desc", callback);
    },
    getAllbannersWithLimit: function (start,limit,callback) {
        var que = "SELECT `id`, `name`, `pic`, `pic_web`, `type`,target,sequence,banner_position FROM `banners` order by id desc limit "+start+','+limit+" ";
        return db.query(que, callback);
    }
};
module.exports = banners;