//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var discounts = {
    //All categories list
    getAlldiscounts: function (callback) {
        return db.query("SELECT `id`, `discount_type_id`, `currency_id`, `discount_var_id`, `value`,image FROM `discounts` order by id desc ", callback);
    },
    getActiveDiscountsWithDetail: function (callback) {
        return db.query("SELECT `id`, `discount_type_id`, `currency_id`, `discount_var_id`, `value`,image FROM `discounts` order by id desc ", callback);
    }
};
module.exports = discounts;