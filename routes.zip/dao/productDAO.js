//reference of dbconnection.js
var db = require('../config/dbconnection'); 
const common = require('../common');
var productsQuery = "SELECT p.id, p.title, p.description, p.category_id, p.category2_id, p.category3_id, p.actual_price, p.is_active, p.brand_id, p.product_image, p.thumb_image1,p.tags,b.name as brand_name, c.name as category1,c2.name as category2,c3.name as category3 FROM products p left join brands b on b.id = p.brand_id left join categories c on c.id = p.category_id left join categories c2 on c2.id = p.category2_id left join categories c3 on c3.id = p.category3_id ";
var products = {
    //All categories list
    getAllProducts: function (limit,callback) {
        var que = productsQuery + " ";
        if(limit != ''){
            que += " limit " + limit;
        }
        return db.query(que, callback);
    },
    getAllProductsWithLimit: function (start,limit,callback) {
        var que = productsQuery + " ";
        if(limit != ''){
            que += " limit "+start+", " + limit;
        }
        return db.query(que, callback);
    },
    getProductById: function (reqObj, callback) {
        return db.query( productsQuery + " where p.id in ("+reqObj.product_id+") ", callback);
    },
    getSubCategoryProducts: function(reqObj, callback){
        var sub_category_id = common.gNUE(reqObj.sub_category_id);
        var limit = common.gNUE(reqObj.limit);
        var limit_from = common.gNUE(reqObj.limit_from);
        var sort = common.gNUE(reqObj.sort);
        var sortType = common.gNUE(reqObj.sortType); // popularity, price low-high/high-low, alphabetical order
        var search_string = common.gNUE(reqObj.search_string);

        var limitQue = "";
        var whereCond = " ";
        if(sub_category_id != ''){
            whereCond = " and p.category2_id in ("+sub_category_id+") and c2.parent_cat_id != '' ";
        }
        if(search_string != ''){
            whereCond += " and ( p.title like '%"+search_string+"%' or c.name like '%"+search_string+"%' or c2.name like '%"+search_string+"%' ) ";
        }
        if(sortType == 'popularity'){
            var query = "SELECT oi.product_id,sum(oi.quantity) as quantity,p.*,b.name as brand_name,c.name as category_name,c2.name as sub_category_name FROM order_items oi ";
            query += " left join products p on p.id = oi.product_id ";
            query += " left join brands b on b.id = p.brand_id ";
            query += " left join categories c on c.id = p.category_id ";
            query += " left join categories c2 on c2.id = p.category2_id ";
            query += " where p.is_deleted = 0 " + whereCond;
            query += " group by oi.product_id ";
            query += " order by quantity "+sort+" ";
        }else if(sortType == 'plh' || sortType == 'phl'){
            // price low to high or high to low
            var query = " select ps.skid,p.* from product_sku ps ";
            query += " left join products p on p.id = ps.product_id ";
            query += " left join categories c on c.id = p.category_id ";
            query += " left join categories c2 on c2.id = p.category2_id ";
            query += " where p.is_deleted = 0 " + whereCond;
            query += " order by ps.actual_price ";
            if(sortType == 'plh'){
                query += " asc ";
            }else if(sortType == 'phl'){
                query += " desc ";
            }
        }else{
            var query = "SELECT p.*,(actual_price - offer_price) as discount_price,c.name as category_name,c2.name as sub_category_name FROM products p ";
            query += " left join categories c on c.id = p.category_id ";
            query += " left join categories c2 on c2.id = p.category2_id ";
            query += " where p.is_deleted = 0 " + whereCond;
            
            if(sortType == 'alphabetical'){
                query += " order by p.title asc ";
            }else if(sortType == 'percenthl'){
                query += " order by p.offer_price desc ";
            }else if(sortType == 'ruplh' || sortType == 'ruphl'){
                // rupee saving high to low / low to high
                query += " order by discount_price  ";
                if(sortType == 'ruplh'){
                    query += " asc ";
                }else if(sortType == 'ruphl'){
                    query += " desc ";
                }
            }else if(sort != ''){
                query += " order by p.id "+sort+" ";
            }
        }

        if(limit != '' && limit_from != ''){
            limitQue = " limit  "+ limit_from + "," + limit;
        }
        query = query + limitQue;
        return db.query( query, callback);
    },
    getRefineProductsBySubcategoryId: function(reqObj, callback){
        var sub_category_id = common.gNUE(reqObj.sub_category_id);
        var limit = common.gNUE(reqObj.limit);
        var limit_from = common.gNUE(reqObj.limit_from);
        var sort = common.gNUE(reqObj.sort);
        var brand_id = common.gNUE(reqObj.brand_id);
        var price_from = common.gNUE(reqObj.price_from);
        var price_to = common.gNUE(reqObj.price_to);
        var discount = common.gNUE(reqObj.discount);
        var search_string = common.gNUE(reqObj.search_string);

        var discountEle = "";var discountWhere = "";
        if(discount != ''){
            discountEle = " ,((ps.actual_price - ps.offer_price)/ps.actual_price) * 100 as discount_percentage";
            discountWhere = " and discount_percentage = '"+discount+"' ";
        }
        
        var limitQue = "";
        var whereCond = " ";
        if(sub_category_id != ''){
            whereCond = " and p.category2_id in ("+sub_category_id+") and c2.parent_cat_id != '' ";
        }
        if(search_string != ''){
            whereCond += " and ( p.title like '%"+search_string+"%' or c.name like '%"+search_string+"%' or c2.name like '%"+search_string+"%' ) ";
        }
        var query = " select ps.skid,p.*"+discountEle+" from product_sku ps ";
        query += " left join products p on p.id = ps.product_id ";
        query += " left join categories c on c.id = p.category_id ";
        query += " left join categories c2 on c2.id = p.category2_id ";
        query += " where p.is_deleted = 0 " + whereCond + discountWhere;

        if(brand_id != ''){
            query += " and p.brand_id in ("+brand_id+") ";
        }

        if(price_from != '' && price_to != ''){
            query += " and ps.actual_price <= "+price_from+" and ps.actual_price >= "+price_to+" ";
        }

        query += " order by ps.actual_price " + sort;
        if(limit != '' && limit_from != ''){
            limitQue = " limit  "+ limit_from + "," + limit;
        }
        query = query + limitQue;
        return db.query( query, callback);
    }
};

module.exports = products;

