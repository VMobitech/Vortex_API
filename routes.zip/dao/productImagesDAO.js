//reference of dbconnection.js
var db = require('../config/dbconnection'); 
var productImages = {
    getProductImagesByProductId: function (product_id,callback) {
        return db.query("SELECT id, product_id, product_image, thumb_image, status FROM product_images WHERE product_id in ("+product_id+")", callback);
    }
};
module.exports = productImages;