var db = require('../config/dbconnection'); //reference of dbconnection.js
const common = require('../common');

var UsersAddress = {
    getAllMyAddress : function(decodedToken,callback){
        return db.query("SELECT `ua_id`,`ua_nick_name`, `ua_first_name`, `user_id`, `ua_last_name`, `ua_mobile_number`, `ua_house_no`, `ua_apartment_name`, `ua_street_details`, `ua_land_mark`, `ua_area_details`, `ua_city`, `ua_pincode`, `ua_created_on`, `ua_updated_on`, `ua_status` FROM `user_address` WHERE user_id = ? ", [decodedToken.u_id], callback);
    },
    addMyAddress : function(user_data,callback){

        var addressFields = {
            ua_nick_name : user_data.ua_nick_name,
            ua_first_name:user_data.ua_first_name,
            ua_last_name:user_data.ua_last_name,
            ua_mobile_number:user_data.ua_mobile_number,
            ua_house_no:user_data.ua_house_no,
            ua_apartment_name:user_data.ua_apartment_name,
            ua_street_details:user_data.ua_street_details,
            ua_land_mark:user_data.ua_land_mark,
            ua_area_details:user_data.ua_area_details,
            ua_city:user_data.ua_city,
            ua_pincode:user_data.ua_pincode,
            ua_created_on:'now()',
            ua_updated_on:'now()'
        };
        var query = common.formInsertQuery({table_name:'user_address',fields:addressFields,type:'insert'});
        return db.query(query, callback);
    },
    updateAddressByAddressId : function(user_data,callback){
        return db.query("update user_address set ua_nick_name=?,ua_first_name=?,ua_last_name=?,ua_mobile_number=?,ua_house_no=?,ua_apartment_name=?,ua_street_details=?,ua_land_mark=?,ua_area_details=?,ua_city=?,ua_pincode=?,ua_updated_on=? where ua_id=?",
        [user_data.ua_nick_name,user_data.ua_first_name,user_data.ua_last_name,user_data.ua_mobile_number,user_data.ua_house_no,user_data.ua_apartment_name,user_data.ua_street_details,user_data.ua_land_mark,user_data.ua_area_details,user_data.ua_city,user_data.ua_pincode,user_data.ua_updated_on,user_data.ua_id], callback);
    }
};
module.exports = UsersAddress;
