var db = require('../config/dbconnection'); //reference of dbconnection.js

var utils = {
    searchProductByName: function (search_string, callback) {
        return db.query("SELECT `id`, `title`, `description`, `category_id`, `actual_price`, `is_active`, `brand_id`,  `product_image`, `thumb_image1` FROM `products` where `title` like '%"+search_string+"%'", callback);
    },
    searchProductsByCatName: function (search_string, callback) {
        return db.query("SELECT p.id, p.title, p.`description`, p.`category_id`, p.`actual_price`, p.`is_active`, p.`brand_id`,  `product_image`, `thumb_image1` FROM `products` p INNER JOIN `categories` c on p.`category_id` = c.`id`  where c.name like '%"+search_string+"%'", callback);
        
    }
};
module.exports = utils;