//reference of dbconnection.js
var db = require('../config/dbconnection'); 
// `skid`, `product_id`, `sku`, `size`, `size_measuring_unit`, `box_color`, `filter_color`, `actual_price`, `min_quantity`, `stock`, `selling_price`, `status`,tax,realization,mrp
var sku = {
    getProductSkuByProductId: function (product_id,callback) {
        return db.query("SELECT * FROM `product_sku` where product_id in ("+product_id+")", callback);
    },
    getProductSkuByProductIdAndSkuId: function (reqParamsObj,callback) {
        var product_id = reqParamsObj.product_id;
        var sku_ids = reqParamsObj.sku_ids;
        var que = "SELECT * FROM `product_sku` where product_id in ("+product_id+") and skid in ("+sku_ids+") ";
        return db.query(que, callback);
    }
};
module.exports = sku;