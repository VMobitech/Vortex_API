var express=require("express");
var app=express();
var bodyParser=require("body-parser");
var multer=require("multer");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
var upload = multer();
app.use(upload.array()); 


app.post("/",function(req,res) {

	console.log(req.body);
	
	res.send(req.body.name);
})
app.listen(2000)